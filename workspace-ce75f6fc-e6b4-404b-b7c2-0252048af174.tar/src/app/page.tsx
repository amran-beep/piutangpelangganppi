'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { CalendarIcon, Plus, Search, Download, Printer, RotateCcw, LogOut, Users, DollarSign, TrendingUp, FileText, Building, Edit, Trash2, UserPlus } from 'lucide-react'
import { format } from 'date-fns'
import { id } from 'date-fns/locale'

interface Transaction {
  id: string
  customerId: string
  customer: {
    id: string
    name: string
    division: string
  }
  type: 'debt' | 'payment'
  amount: number
  description: string
  date: string
  division: string
  createdAt: string
  updatedAt: string
}

interface Customer {
  id: string
  name: string
  phone?: string
  address?: string
  email?: string
  division: string
  totalDebt?: number
  totalPayment?: number
  remainingDebt?: number
  transactionCount?: number
  transactions?: Transaction[]
}

export default function KasbonApp() {
  const [customers, setCustomers] = useState<Customer[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([])
  const [formData, setFormData] = useState({
    customerName: '',
    division: 'RMM' as 'RMM' | 'BSL' | 'RP',
    type: 'debt' as 'debt' | 'payment',
    amount: '',
    description: '',
    date: new Date().toISOString().split('T')[0]
  })
  const [customerFormData, setCustomerFormData] = useState({
    name: '',
    phone: '',
    address: '',
    email: '',
    division: 'RMM' as 'RMM' | 'BSL' | 'RP'
  })
  const [filterData, setFilterData] = useState({
    customerName: '',
    type: 'all',
    startDate: '',
    endDate: ''
  })
  const [isResetDialogOpen, setIsResetDialogOpen] = useState(false)
  const [isLogoutDialogOpen, setIsLogoutDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isCustomerDialogOpen, setIsCustomerDialogOpen] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)
  const [editFormData, setEditFormData] = useState({
    customerName: '',
    division: 'RMM' as 'RMM' | 'BSL' | 'RP',
    type: 'debt' as 'debt' | 'payment',
    amount: '',
    description: '',
    date: ''
  })

  // Load data from API on mount
  useEffect(() => {
    fetchCustomers()
    fetchTransactions()
  }, [])

  const fetchCustomers = async () => {
    try {
      const response = await fetch('/api/customers')
      const result = await response.json()
      if (result.success) {
        setCustomers(result.data)
      }
    } catch (error) {
      console.error('Error fetching customers:', error)
    }
  }

  const fetchTransactions = async () => {
    try {
      const response = await fetch('/api/transactions')
      const result = await response.json()
      if (result.success) {
        setTransactions(result.data)
        setFilteredTransactions(result.data)
      }
    } catch (error) {
      console.error('Error fetching transactions:', error)
    }
  }

  // Apply filters
  useEffect(() => {
    let filtered = [...transactions]

    if (filterData.customerName) {
      filtered = filtered.filter(t => 
        t.customer.name.toLowerCase().includes(filterData.customerName.toLowerCase())
      )
    }

    if (filterData.type !== 'all') {
      filtered = filtered.filter(t => t.type === filterData.type)
    }

    if (filterData.startDate) {
      filtered = filtered.filter(t => t.date >= filterData.startDate)
    }

    if (filterData.endDate) {
      filtered = filtered.filter(t => t.date <= filterData.endDate)
    }

    setFilteredTransactions(filtered)
  }, [transactions, filterData])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.customerName || !formData.amount || !formData.description) {
      alert('Mohon lengkapi semua field yang diperlukan')
      return
    }

    try {
      const response = await fetch('/api/transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          customerName: formData.customerName,
          division: formData.division,
          type: formData.type,
          amount: formData.amount,
          description: formData.description,
          date: formData.date
        })
      })

      const result = await response.json()
      if (result.success) {
        await fetchTransactions()
        await fetchCustomers()
        
        // Reset form
        setFormData({
          customerName: '',
          division: 'RMM',
          type: 'debt',
          amount: '',
          description: '',
          date: new Date().toISOString().split('T')[0]
        })

        alert('Transaksi berhasil ditambahkan!')
      } else {
        alert('Gagal menambahkan transaksi: ' + result.error)
      }
    } catch (error) {
      console.error('Error creating transaction:', error)
      alert('Terjadi kesalahan saat menambahkan transaksi')
    }
  }

  const handleCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!customerFormData.name || !customerFormData.division) {
      alert('Mohon lengkapi nama pelanggan dan divisi')
      return
    }

    try {
      const response = await fetch('/api/customers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(customerFormData)
      })

      const result = await response.json()
      if (result.success) {
        await fetchCustomers()
        
        // Reset form
        setCustomerFormData({
          name: '',
          phone: '',
          address: '',
          email: '',
          division: 'RMM'
        })

        setIsCustomerDialogOpen(false)
        alert('Pelanggan berhasil ditambahkan!')
      } else {
        alert('Gagal menambahkan pelanggan: ' + result.error)
      }
    } catch (error) {
      console.error('Error creating customer:', error)
      alert('Terjadi kesalahan saat menambahkan pelanggan')
    }
  }

  const handleEdit = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setEditFormData({
      customerName: transaction.customer.name,
      division: transaction.division,
      type: transaction.type,
      amount: transaction.amount.toString(),
      description: transaction.description,
      date: transaction.date
    })
    setIsEditDialogOpen(true)
  }

  const handleUpdate = async () => {
    if (!selectedTransaction) return

    try {
      const response = await fetch('/api/transactions', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: selectedTransaction.id,
          customerName: editFormData.customerName,
          division: editFormData.division,
          type: editFormData.type,
          amount: editFormData.amount,
          description: editFormData.description,
          date: editFormData.date
        })
      })

      const result = await response.json()
      if (result.success) {
        await fetchTransactions()
        await fetchCustomers()
        setIsEditDialogOpen(false)
        setSelectedTransaction(null)
        alert('Transaksi berhasil diperbarui!')
      } else {
        alert('Gagal memperbarui transaksi: ' + result.error)
      }
    } catch (error) {
      console.error('Error updating transaction:', error)
      alert('Terjadi kesalahan saat memperbarui transaksi')
    }
  }

  const handleDelete = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setIsDeleteDialogOpen(true)
  }

  const confirmDelete = async () => {
    if (!selectedTransaction) return

    try {
      const response = await fetch(`/api/transactions?id=${selectedTransaction.id}`, {
        method: 'DELETE'
      })

      const result = await response.json()
      if (result.success) {
        await fetchTransactions()
        await fetchCustomers()
        setIsDeleteDialogOpen(false)
        setSelectedTransaction(null)
        alert('Transaksi berhasil dihapus!')
      } else {
        alert('Gagal menghapus transaksi: ' + result.error)
      }
    } catch (error) {
      console.error('Error deleting transaction:', error)
      alert('Terjadi kesalahan saat menghapus transaksi')
    }
  }

  const handleReset = async () => {
    try {
      const response = await fetch('/api/transactions', {
        method: 'DELETE'
      })

      const result = await response.json()
      if (result.success) {
        await fetchTransactions()
        await fetchCustomers()
        setIsResetDialogOpen(false)
        alert('Semua transaksi telah direset!')
      } else {
        alert('Gagal mereset transaksi: ' + result.error)
      }
    } catch (error) {
      console.error('Error resetting transactions:', error)
      alert('Terjadi kesalahan saat mereset transaksi')
    }
  }

  const handleBackupPDF = async () => {
    try {
      const response = await fetch('/api/backup')
      if (response.ok) {
        const blob = await response.blob()
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `piutang-ppi-report-${new Date().toISOString().split('T')[0]}.txt`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)

        alert('Backup berhasil diunduh!')
      }
    } catch (error) {
      console.error('Error downloading backup:', error)
      alert('Terjadi kesalahan saat mengunduh backup')
    }
  }

  // Print functions for A4 size
  const printSummaryA4 = () => {
    const printWindow = window.open('', '', 'width=794,height=1123')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Ringkasan Hutang Pelanggan</title>
            <style>
              @page {
                size: A4;
                margin: 15mm;
              }
              body { 
                font-family: Arial, sans-serif; 
                font-size: 12px;
                line-height: 1.4;
                margin: 0;
                padding: 0;
              }
              .header { 
                text-align: center; 
                margin-bottom: 30px;
                border-bottom: 2px solid #333;
                padding-bottom: 15px;
              }
              .header h1 { 
                font-size: 18px; 
                margin: 5px 0;
                font-weight: bold;
              }
              .header h2 { 
                font-size: 14px; 
                margin: 3px 0;
                font-weight: normal;
              }
              .header p { 
                font-size: 11px; 
                margin: 2px 0;
                color: #666;
              }
              table { 
                border-collapse: collapse; 
                width: 100%; 
                margin-bottom: 20px;
              }
              th, td { 
                border: 1px solid #333; 
                padding: 6px 8px; 
                text-align: left; 
                font-size: 11px;
              }
              th { 
                background-color: #f0f0f0; 
                font-weight: bold;
                font-size: 11px;
              }
              .text-right { text-align: right; }
              .text-center { text-align: center; }
              .bold { font-weight: bold; }
              .positive { color: #006400; font-weight: bold; }
              .negative { color: #8B0000; font-weight: bold; }
              .footer { 
                text-align: center; 
                margin-top: 30px; 
                font-size: 10px; 
                color: #666;
                border-top: 1px solid #ccc;
                padding-top: 10px;
              }
              .total-row {
                background-color: #f9f9f9;
                font-weight: bold;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>PIUTANG PELANGGAN PPI</h1>
              <h2>PT RURA SEJAHTERA GRUP</h2>
              <p>LAPORAN RINGKASAN HUTANG PER PELANGGAN</p>
              <p>Tanggal Cetak: ${new Date().toLocaleDateString('id-ID')} ${new Date().toLocaleTimeString('id-ID')}</p>
            </div>
            
            <table>
              <thead>
                <tr>
                  <th width="25%">Nama Pelanggan</th>
                  <th width="20%" class="text-right">Total Hutang</th>
                  <th width="20%" class="text-right">Total Pembayaran</th>
                  <th width="20%" class="text-right">Sisa Hutang</th>
                  <th width="15%" class="text-center">Jumlah Transaksi</th>
                </tr>
              </thead>
              <tbody>
                ${customers.map(customer => `
                  <tr>
                    <td>${customer.name}</td>
                    <td class="text-right">Rp ${(customer.totalDebt || 0).toLocaleString('id-ID')}</td>
                    <td class="text-right">Rp ${(customer.totalPayment || 0).toLocaleString('id-ID')}</td>
                    <td class="text-right ${(customer.remainingDebt || 0) > 0 ? 'negative' : 'positive'}">Rp ${(customer.remainingDebt || 0).toLocaleString('id-ID')}</td>
                    <td class="text-center">${customer.transactionCount || 0}</td>
                  </tr>
                `).join('')}
                <tr class="total-row">
                  <td class="bold">TOTAL</td>
                  <td class="text-right bold">Rp ${customers.reduce((sum, c) => sum + (c.totalDebt || 0), 0).toLocaleString('id-ID')}</td>
                  <td class="text-right bold">Rp ${customers.reduce((sum, c) => sum + (c.totalPayment || 0), 0).toLocaleString('id-ID')}</td>
                  <td class="text-right bold ${customers.reduce((sum, c) => sum + (c.remainingDebt || 0), 0) > 0 ? 'negative' : 'positive'}">Rp ${customers.reduce((sum, c) => sum + (c.remainingDebt || 0), 0).toLocaleString('id-ID')}</td>
                  <td class="text-center bold">${customers.reduce((sum, c) => sum + (c.transactionCount || 0), 0)}</td>
                </tr>
              </tbody>
            </table>
            
            <div class="footer">
              <p>apps created by @alyafta.id 2025</p>
            </div>
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  const printRecapA4 = () => {
    const printWindow = window.open('', '', 'width=794,height=1123')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Rekap Transaksi Pelanggan</title>
            <style>
              @page {
                size: A4;
                margin: 15mm;
              }
              body { 
                font-family: Arial, sans-serif; 
                font-size: 10px;
                line-height: 1.3;
                margin: 0;
                padding: 0;
              }
              .header { 
                text-align: center; 
                margin-bottom: 20px;
                border-bottom: 2px solid #333;
                padding-bottom: 10px;
              }
              .header h1 { 
                font-size: 16px; 
                margin: 3px 0;
                font-weight: bold;
              }
              .header h2 { 
                font-size: 12px; 
                margin: 2px 0;
                font-weight: normal;
              }
              .header p { 
                font-size: 10px; 
                margin: 1px 0;
                color: #666;
              }
              .customer-section {
                margin-bottom: 25px;
                page-break-inside: avoid;
              }
              .customer-header {
                background-color: #f0f0f0;
                padding: 8px;
                border: 1px solid #333;
                margin-bottom: 5px;
                font-weight: bold;
              }
              .customer-info {
                display: flex;
                justify-content: space-between;
                margin-bottom: 5px;
              }
              table { 
                border-collapse: collapse; 
                width: 100%; 
                font-size: 9px;
              }
              th, td { 
                border: 1px solid #333; 
                padding: 4px 6px; 
                text-align: left; 
              }
              th { 
                background-color: #f0f0f0; 
                font-weight: bold;
              }
              .text-right { text-align: right; }
              .text-center { text-align: center; }
              .badge { 
                background-color: #e0e0e0; 
                padding: 2px 4px; 
                border-radius: 3px;
                font-size: 8px;
              }
              .positive { color: #006400; font-weight: bold; }
              .negative { color: #8B0000; font-weight: bold; }
              .footer { 
                text-align: center; 
                margin-top: 30px; 
                font-size: 9px; 
                color: #666;
                border-top: 1px solid #ccc;
                padding-top: 10px;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>PIUTANG PELANGGAN PPI</h1>
              <h2>PT RURA SEJAHTERA GRUP</h2>
              <p>LAPORAN REKAP TRANSAKSI PER PELANGGAN</p>
              <p>Tanggal Cetak: ${new Date().toLocaleDateString('id-ID')} ${new Date().toLocaleTimeString('id-ID')}</p>
            </div>
            
            ${customers.map(customer => `
              <div class="customer-section">
                <div class="customer-header">
                  <div style="font-size: 12px;">${customer.name}</div>
                  <div class="customer-info">
                    <span>Hutang: <span class="negative">Rp ${(customer.totalDebt || 0).toLocaleString('id-ID')}</span></span>
                    <span>Bayar: <span class="positive">Rp ${(customer.totalPayment || 0).toLocaleString('id-ID')}</span></span>
                    <span>Sisa: <span class="${(customer.remainingDebt || 0) > 0 ? 'negative' : 'positive'}">Rp ${(customer.remainingDebt || 0).toLocaleString('id-ID')}</span></span>
                  </div>
                </div>
                <table>
                  <thead>
                    <tr>
                      <th width="12%">Tanggal</th>
                      <th width="8%">Divisi</th>
                      <th width="10%">Jenis</th>
                      <th width="20%" class="text-right">Jumlah</th>
                      <th width="50%">Keterangan</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${(customer.transactions || [])
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map(transaction => `
                      <tr>
                        <td>${transaction.date}</td>
                        <td><span class="badge">${transaction.division}</span></td>
                        <td>${transaction.type === 'debt' ? 'Hutang' : 'Bayar'}</td>
                        <td class="text-right">Rp ${transaction.amount.toLocaleString('id-ID')}</td>
                        <td>${transaction.description}</td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            `).join('')}
            
            <div class="footer">
              <p>apps created by @alyafta.id 2025</p>
            </div>
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  const printHistoryA4 = () => {
    const printWindow = window.open('', '', 'width=794,height=1123')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Riwayat Transaksi</title>
            <style>
              @page {
                size: A4;
                margin: 15mm;
              }
              body { 
                font-family: Arial, sans-serif; 
                font-size: 11px;
                line-height: 1.4;
                margin: 0;
                padding: 0;
              }
              .header { 
                text-align: center; 
                margin-bottom: 25px;
                border-bottom: 2px solid #333;
                padding-bottom: 15px;
              }
              .header h1 { 
                font-size: 18px; 
                margin: 5px 0;
                font-weight: bold;
              }
              .header h2 { 
                font-size: 14px; 
                margin: 3px 0;
                font-weight: normal;
              }
              .header p { 
                font-size: 11px; 
                margin: 2px 0;
                color: #666;
              }
              .filter-info {
                background-color: #f9f9f9;
                padding: 10px;
                border: 1px solid #ddd;
                margin-bottom: 20px;
                font-size: 10px;
              }
              table { 
                border-collapse: collapse; 
                width: 100%; 
                margin-bottom: 20px;
              }
              th, td { 
                border: 1px solid #333; 
                padding: 6px 8px; 
                text-align: left; 
                font-size: 10px;
              }
              th { 
                background-color: #f0f0f0; 
                font-weight: bold;
                font-size: 10px;
              }
              .text-right { text-align: right; }
              .text-center { text-align: center; }
              .badge { 
                background-color: #e0e0e0; 
                padding: 2px 4px; 
                border-radius: 3px;
                font-size: 8px;
              }
              .debt-badge { 
                background-color: #ffebee; 
                color: #c62828;
                padding: 2px 4px; 
                border-radius: 3px;
                font-size: 8px;
              }
              .payment-badge { 
                background-color: #e8f5e8; 
                color: #2e7d32;
                padding: 2px 4px; 
                border-radius: 3px;
                font-size: 8px;
              }
              .footer { 
                text-align: center; 
                margin-top: 30px; 
                font-size: 10px; 
                color: #666;
                border-top: 1px solid #ccc;
                padding-top: 10px;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>PIUTANG PELANGGAN PPI</h1>
              <h2>PT RURA SEJAHTERA GRUP</h2>
              <p>LAPORAN RIWAYAT TRANSAKSI</p>
              <p>Tanggal Cetak: ${new Date().toLocaleDateString('id-ID')} ${new Date().toLocaleTimeString('id-ID')}</p>
            </div>
            
            <div class="filter-info">
              <strong>Filter Aktif:</strong> 
              ${filterData.customerName ? `Pelanggan: ${filterData.customerName}` : 'Semua Pelanggan'}
              ${filterData.type !== 'all' ? ` | Jenis: ${filterData.type === 'debt' ? 'Hutang' : 'Pembayaran'}` : ''}
              ${filterData.startDate ? ` | Dari: ${filterData.startDate}` : ''}
              ${filterData.endDate ? ` | Sampai: ${filterData.endDate}` : ''}
              <br>
              <strong>Total Transaksi:</strong> ${filteredTransactions.length} dari ${transactions.length}
            </div>
            
            <table>
              <thead>
                <tr>
                  <th width="10%">Tanggal</th>
                  <th width="20%">Pelanggan</th>
                  <th width="8%">Divisi</th>
                  <th width="10%">Jenis</th>
                  <th width="18%" class="text-right">Jumlah</th>
                  <th width="34%">Keterangan</th>
                </tr>
              </thead>
              <tbody>
                ${filteredTransactions.map(transaction => `
                  <tr>
                    <td>${transaction.date}</td>
                    <td>${transaction.customer.name}</td>
                    <td><span class="badge">${transaction.division}</span></td>
                    <td><span class="${transaction.type === 'debt' ? 'debt-badge' : 'payment-badge'}">${transaction.type === 'debt' ? 'Hutang' : 'Bayar'}</span></td>
                    <td class="text-right">Rp ${transaction.amount.toLocaleString('id-ID')}</td>
                    <td>${transaction.description}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            
            <div class="footer">
              <p>apps created by @alyafta.id 2025</p>
            </div>
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  const handleLogout = () => {
    setIsLogoutDialogOpen(false)
    
    alert('Aplikasi akan ditutup.')
    
    // Close window/tab
    window.close()
    
    // Fallback if window.close() doesn't work
    setTimeout(() => {
      window.location.href = 'about:blank'
    }, 1000)
  }

  const totalDebt = customers.reduce((sum, customer) => sum + (customer.totalDebt || 0), 0)
  const totalPayment = customers.reduce((sum, customer) => sum + (customer.totalPayment || 0), 0)
  const totalRemaining = totalDebt - totalPayment

  // Group transactions by customer for recap
  const groupedTransactions = customers.reduce((acc: { [key: string]: Transaction[] }, customer) => {
    acc[customer.name] = customer.transactions || []
    return acc
  }, {})

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6 rounded-lg shadow-lg mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <DollarSign className="w-8 h-8" />
                Piutang Pelanggan PPI
              </h1>
              <h2 className="text-xl text-blue-100 mt-1">PT RURA SEJAHTERA GRUP</h2>
              <p className="text-blue-100 mt-2">Sistem pencatatan hutang dan pembayaran pelanggan</p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="secondary" 
                onClick={handleBackupPDF}
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                <Download className="w-4 h-4 mr-2" />
                Backup PDF
              </Button>
              <Button 
                variant="destructive" 
                onClick={() => setIsResetDialogOpen(true)}
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setIsLogoutDialogOpen(true)}
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-white border-blue-200 shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Pelanggan</p>
                  <p className="text-2xl font-bold text-blue-600">{customers.length}</p>
                </div>
                <Users className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white border-blue-200 shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Hutang</p>
                  <p className="text-2xl font-bold text-red-600">Rp {totalDebt.toLocaleString('id-ID')}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white border-blue-200 shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Pembayaran</p>
                  <p className="text-2xl font-bold text-green-600">Rp {totalPayment.toLocaleString('id-ID')}</p>
                </div>
                <DollarSign className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white border-blue-200 shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Sisa Hutang</p>
                  <p className="text-2xl font-bold text-orange-600">Rp {totalRemaining.toLocaleString('id-ID')}</p>
                </div>
                <FileText className="w-8 h-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="transaction" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-blue-100">
            <TabsTrigger value="transaction" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Input Transaksi
            </TabsTrigger>
            <TabsTrigger value="customer" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Data Pelanggan
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Riwayat Transaksi
            </TabsTrigger>
          </TabsList>

          {/* Transaction Form */}
          <TabsContent value="transaction">
            <Card className="bg-white border-blue-200 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Input Transaksi Baru
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Tambahkan transaksi hutang atau pembayaran pelanggan
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="customerName" className="text-blue-700 font-medium">Nama Pelanggan</Label>
                      <Input
                        id="customerName"
                        value={formData.customerName}
                        onChange={(e) => setFormData({...formData, customerName: e.target.value})}
                        placeholder="Masukkan nama pelanggan"
                        className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="division" className="text-blue-700 font-medium">Divisi</Label>
                      <Select value={formData.division} onValueChange={(value: 'RMM' | 'BSL' | 'RP') => setFormData({...formData, division: value})}>
                        <SelectTrigger className="border-blue-200 focus:border-blue-500 focus:ring-blue-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="RMM">RMM</SelectItem>
                          <SelectItem value="BSL">BSL</SelectItem>
                          <SelectItem value="RP">RP</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="type" className="text-blue-700 font-medium">Jenis Transaksi</Label>
                      <Select value={formData.type} onValueChange={(value: 'debt' | 'payment') => setFormData({...formData, type: value})}>
                        <SelectTrigger className="border-blue-200 focus:border-blue-500 focus:ring-blue-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="debt">Hutang</SelectItem>
                          <SelectItem value="payment">Pembayaran</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="amount" className="text-blue-700 font-medium">Jumlah (Rp)</Label>
                      <Input
                        id="amount"
                        type="number"
                        value={formData.amount}
                        onChange={(e) => setFormData({...formData, amount: e.target.value})}
                        placeholder="Masukkan jumlah"
                        className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="date" className="text-blue-700 font-medium">Tanggal</Label>
                      <Input
                        id="date"
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({...formData, date: e.target.value})}
                        className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="description" className="text-blue-700 font-medium">Keterangan</Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      placeholder="Masukkan keterangan transaksi"
                      className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                      required
                    />
                  </div>
                  
                  <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium">
                    <Plus className="w-4 h-4 mr-2" />
                    Tambah Transaksi
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Customer Management */}
          <TabsContent value="customer">
            <div className="space-y-6">
              <Card className="bg-white border-blue-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center gap-2">
                      <UserPlus className="w-5 h-5" />
                      Tambah Pelanggan Baru
                    </CardTitle>
                    <Button 
                      onClick={() => setIsCustomerDialogOpen(true)}
                      className="bg-white text-blue-600 hover:bg-blue-50"
                      size="sm"
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Tambah Pelanggan
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-blue-50">
                          <TableHead className="text-blue-700">Nama Pelanggan</TableHead>
                          <TableHead className="text-blue-700">Divisi</TableHead>
                          <TableHead className="text-blue-700">Telepon</TableHead>
                          <TableHead className="text-blue-700">Email</TableHead>
                          <TableHead className="text-blue-700">Total Hutang</TableHead>
                          <TableHead className="text-blue-700">Total Pembayaran</TableHead>
                          <TableHead className="text-blue-700">Sisa Hutang</TableHead>
                          <TableHead className="text-blue-700">Jumlah Transaksi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {customers.map((customer) => (
                          <TableRow key={customer.id} className="hover:bg-blue-50">
                            <TableCell className="font-medium">{customer.name}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{customer.division}</Badge>
                            </TableCell>
                            <TableCell>{customer.phone || '-'}</TableCell>
                            <TableCell>{customer.email || '-'}</TableCell>
                            <TableCell className="text-right text-red-600 font-medium">
                              Rp {(customer.totalDebt || 0).toLocaleString('id-ID')}
                            </TableCell>
                            <TableCell className="text-right text-green-600 font-medium">
                              Rp {(customer.totalPayment || 0).toLocaleString('id-ID')}
                            </TableCell>
                            <TableCell className="text-right font-bold">
                              <span className={(customer.remainingDebt || 0) > 0 ? "text-orange-600" : "text-green-600"}>
                                Rp {(customer.remainingDebt || 0).toLocaleString('id-ID')}
                              </span>
                            </TableCell>
                            <TableCell className="text-center">
                              <Badge variant="secondary">{customer.transactionCount || 0}</Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Transaction History */}
          <TabsContent value="history">
            <div className="space-y-6">
              {/* Filter Section */}
              <Card className="bg-white border-blue-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <CardTitle className="flex items-center gap-2">
                    <Search className="w-5 h-5" />
                    Filter Transaksi
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="filterCustomer" className="text-blue-700 font-medium">Nama Pelanggan</Label>
                      <Input
                        id="filterCustomer"
                        value={filterData.customerName}
                        onChange={(e) => setFilterData({...filterData, customerName: e.target.value})}
                        placeholder="Cari nama pelanggan"
                        className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="filterType" className="text-blue-700 font-medium">Jenis Transaksi</Label>
                      <Select value={filterData.type} onValueChange={(value) => setFilterData({...filterData, type: value})}>
                        <SelectTrigger className="border-blue-200 focus:border-blue-500 focus:ring-blue-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Semua</SelectItem>
                          <SelectItem value="debt">Hutang</SelectItem>
                          <SelectItem value="payment">Pembayaran</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="startDate" className="text-blue-700 font-medium">Tanggal Mulai</Label>
                      <Input
                        id="startDate"
                        type="date"
                        value={filterData.startDate}
                        onChange={(e) => setFilterData({...filterData, startDate: e.target.value})}
                        className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="endDate" className="text-blue-700 font-medium">Tanggal Selesai</Label>
                      <Input
                        id="endDate"
                        type="date"
                        value={filterData.endDate}
                        onChange={(e) => setFilterData({...filterData, endDate: e.target.value})}
                        className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Customer Summary */}
              <Card className="bg-white border-blue-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <div className="flex justify-between items-center">
                    <CardTitle>Ringkasan Hutang Per Pelanggan</CardTitle>
                    <Button 
                      onClick={printSummaryA4}
                      className="bg-white text-blue-600 hover:bg-blue-50"
                      size="sm"
                    >
                      <Printer className="w-4 h-4 mr-2" />
                      Print A4
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-blue-50">
                          <TableHead className="text-blue-700">Nama Pelanggan</TableHead>
                          <TableHead className="text-blue-700 text-right">Total Hutang</TableHead>
                          <TableHead className="text-blue-700 text-right">Total Pembayaran</TableHead>
                          <TableHead className="text-blue-700 text-right">Sisa Hutang</TableHead>
                          <TableHead className="text-blue-700 text-center">Jumlah Transaksi</TableHead>
                          <TableHead className="text-blue-700 text-center">Aksi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {customers.map((customer) => {
                          const customerTransactions = transactions.filter(t => t.customerId === customer.id)
                          return (
                            <TableRow key={customer.id} className="hover:bg-blue-50">
                              <TableCell className="font-medium">{customer.name}</TableCell>
                              <TableCell className="text-right text-red-600 font-medium">
                                Rp {(customer.totalDebt || 0).toLocaleString('id-ID')}
                              </TableCell>
                              <TableCell className="text-right text-green-600 font-medium">
                                Rp {(customer.totalPayment || 0).toLocaleString('id-ID')}
                              </TableCell>
                              <TableCell className="text-right font-bold">
                                <span className={(customer.remainingDebt || 0) > 0 ? "text-orange-600" : "text-green-600"}>
                                  Rp {(customer.remainingDebt || 0).toLocaleString('id-ID')}
                                </span>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge variant="secondary">{customer.transactionCount || 0}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <div className="flex gap-2 justify-center">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      if (customerTransactions.length > 0) {
                                        handleEdit(customerTransactions[customerTransactions.length - 1])
                                      }
                                    }}
                                    className="text-blue-600 hover:text-blue-800"
                                  >
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      if (customerTransactions.length > 0) {
                                        handleDelete(customerTransactions[customerTransactions.length - 1])
                                      }
                                    }}
                                    className="text-red-600 hover:text-red-800"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Recap Transaksi by Customer */}
              <Card className="bg-white border-blue-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Rekap Transaksi Per Pelanggan</CardTitle>
                      <CardDescription className="text-blue-100">
                        Mengelompokkan transaksi berdasarkan nama pelanggan (tanpa menghiraukan divisi)
                      </CardDescription>
                    </div>
                    <Button 
                      onClick={printRecapA4}
                      className="bg-white text-blue-600 hover:bg-blue-50"
                      size="sm"
                    >
                      <Printer className="w-4 h-4 mr-2" />
                      Print A4
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    {Object.entries(groupedTransactions).map(([customerName, customerTransactions]) => {
                      const customer = customers.find(c => c.name === customerName)
                      return (
                        <div key={customerName} className="border border-blue-200 rounded-lg p-4">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold text-blue-800">{customerName}</h3>
                            <div className="flex gap-4 text-sm">
                              <span className="text-red-600 font-medium">
                                Hutang: Rp {(customer?.totalDebt || 0).toLocaleString('id-ID')}
                              </span>
                              <span className="text-green-600 font-medium">
                                Bayar: Rp {(customer?.totalPayment || 0).toLocaleString('id-ID')}
                              </span>
                              <span className="text-orange-600 font-bold">
                                Sisa: Rp {(customer?.remainingDebt || 0).toLocaleString('id-ID')}
                              </span>
                            </div>
                          </div>
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader>
                                <TableRow className="bg-blue-50">
                                  <TableHead className="text-blue-700">Tanggal</TableHead>
                                  <TableHead className="text-blue-700">Divisi</TableHead>
                                  <TableHead className="text-blue-700">Jenis</TableHead>
                                  <TableHead className="text-blue-700 text-right">Jumlah</TableHead>
                                  <TableHead className="text-blue-700">Keterangan</TableHead>
                                  <TableHead className="text-blue-700 text-center">Aksi</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {customerTransactions
                                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                                  .map((transaction) => (
                                  <TableRow key={transaction.id} className="hover:bg-blue-50">
                                    <TableCell>{transaction.date}</TableCell>
                                    <TableCell>
                                      <Badge variant="outline">{transaction.division}</Badge>
                                    </TableCell>
                                    <TableCell>
                                      <Badge 
                                        variant={transaction.type === 'debt' ? 'destructive' : 'default'}
                                        className={transaction.type === 'debt' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}
                                      >
                                        {transaction.type === 'debt' ? 'Hutang' : 'Pembayaran'}
                                      </Badge>
                                    </TableCell>
                                    <TableCell className="text-right font-medium">
                                      Rp {transaction.amount.toLocaleString('id-ID')}
                                    </TableCell>
                                    <TableCell>{transaction.description}</TableCell>
                                    <TableCell className="text-center">
                                      <div className="flex gap-2 justify-center">
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() => handleEdit(transaction)}
                                          className="text-blue-600 hover:text-blue-800"
                                        >
                                          <Edit className="w-4 h-4" />
                                        </Button>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() => handleDelete(transaction)}
                                          className="text-red-600 hover:text-red-800"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </Button>
                                      </div>
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Transaction History Table */}
              <Card className="bg-white border-blue-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Riwayat Transaksi</CardTitle>
                      <CardDescription className="text-blue-100">
                        Menampilkan {filteredTransactions.length} dari {transactions.length} transaksi
                      </CardDescription>
                    </div>
                    <Button 
                      onClick={printHistoryA4}
                      className="bg-white text-blue-600 hover:bg-blue-50"
                      size="sm"
                    >
                      <Printer className="w-4 h-4 mr-2" />
                      Print A4
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div id="printable-content" className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-blue-50">
                          <TableHead className="text-blue-700">Tanggal</TableHead>
                          <TableHead className="text-blue-700">Pelanggan</TableHead>
                          <TableHead className="text-blue-700">Divisi</TableHead>
                          <TableHead className="text-blue-700">Jenis</TableHead>
                          <TableHead className="text-blue-700 text-right">Jumlah</TableHead>
                          <TableHead className="text-blue-700">Keterangan</TableHead>
                          <TableHead className="text-blue-700 text-center">Aksi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredTransactions.map((transaction) => (
                          <TableRow key={transaction.id} className="hover:bg-blue-50">
                            <TableCell>{transaction.date}</TableCell>
                            <TableCell className="font-medium">{transaction.customer.name}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{transaction.division}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge 
                                variant={transaction.type === 'debt' ? 'destructive' : 'default'}
                                className={transaction.type === 'debt' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}
                              >
                                {transaction.type === 'debt' ? 'Hutang' : 'Pembayaran'}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right font-medium">
                              Rp {transaction.amount.toLocaleString('id-ID')}
                            </TableCell>
                            <TableCell>{transaction.description}</TableCell>
                            <TableCell className="text-center">
                              <div className="flex gap-2 justify-center">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleEdit(transaction)}
                                  className="text-blue-600 hover:text-blue-800"
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleDelete(transaction)}
                                  className="text-red-600 hover:text-red-800"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="text-center mt-8 text-gray-600 text-sm">
          <p>apps created by @alyafta.id 2025</p>
        </div>

        {/* Add Customer Dialog */}
        <Dialog open={isCustomerDialogOpen} onOpenChange={setIsCustomerDialogOpen}>
          <DialogContent className="bg-white border-blue-200">
            <DialogHeader>
              <DialogTitle className="text-blue-600">Tambah Pelanggan Baru</DialogTitle>
              <DialogDescription>
                Tambahkan data pelanggan baru ke sistem
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="newCustomerName" className="text-blue-700 font-medium">Nama Pelanggan</Label>
                  <Input
                    id="newCustomerName"
                    value={customerFormData.name}
                    onChange={(e) => setCustomerFormData({...customerFormData, name: e.target.value})}
                    placeholder="Masukkan nama pelanggan"
                    className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newCustomerDivision" className="text-blue-700 font-medium">Divisi</Label>
                  <Select value={customerFormData.division} onValueChange={(value: 'RMM' | 'BSL' | 'RP') => setCustomerFormData({...customerFormData, division: value})}>
                    <SelectTrigger className="border-blue-200 focus:border-blue-500 focus:ring-blue-500">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="RMM">RMM</SelectItem>
                      <SelectItem value="BSL">BSL</SelectItem>
                      <SelectItem value="RP">RP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newCustomerPhone" className="text-blue-700 font-medium">Telepon</Label>
                  <Input
                    id="newCustomerPhone"
                    value={customerFormData.phone}
                    onChange={(e) => setCustomerFormData({...customerFormData, phone: e.target.value})}
                    placeholder="Masukkan nomor telepon"
                    className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newCustomerEmail" className="text-blue-700 font-medium">Email</Label>
                  <Input
                    id="newCustomerEmail"
                    type="email"
                    value={customerFormData.email}
                    onChange={(e) => setCustomerFormData({...customerFormData, email: e.target.value})}
                    placeholder="Masukkan email"
                    className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="newCustomerAddress" className="text-blue-700 font-medium">Alamat</Label>
                <Input
                  id="newCustomerAddress"
                  value={customerFormData.address}
                  onChange={(e) => setCustomerFormData({...customerFormData, address: e.target.value})}
                  placeholder="Masukkan alamat"
                  className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCustomerDialogOpen(false)}>
                Batal
              </Button>
              <Button onClick={handleCustomerSubmit} className="bg-blue-600 hover:bg-blue-700">
                Tambah Pelanggan
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Transaction Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="bg-white border-blue-200">
            <DialogHeader>
              <DialogTitle className="text-blue-600">Edit Transaksi</DialogTitle>
              <DialogDescription>
                Perbarui data transaksi yang dipilih
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="editCustomerName" className="text-blue-700 font-medium">Nama Pelanggan</Label>
                  <Input
                    id="editCustomerName"
                    value={editFormData.customerName}
                    onChange={(e) => setEditFormData({...editFormData, customerName: e.target.value})}
                    placeholder="Masukkan nama pelanggan"
                    className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="editDivision" className="text-blue-700 font-medium">Divisi</Label>
                  <Select value={editFormData.division} onValueChange={(value: 'RMM' | 'BSL' | 'RP') => setEditFormData({...editFormData, division: value})}>
                    <SelectTrigger className="border-blue-200 focus:border-blue-500 focus:ring-blue-500">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="RMM">RMM</SelectItem>
                      <SelectItem value="BSL">BSL</SelectItem>
                      <SelectItem value="RP">RP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="editType" className="text-blue-700 font-medium">Jenis Transaksi</Label>
                  <Select value={editFormData.type} onValueChange={(value: 'debt' | 'payment') => setEditFormData({...editFormData, type: value})}>
                    <SelectTrigger className="border-blue-200 focus:border-blue-500 focus:ring-blue-500">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="debt">Hutang</SelectItem>
                      <SelectItem value="payment">Pembayaran</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="editAmount" className="text-blue-700 font-medium">Jumlah (Rp)</Label>
                  <Input
                    id="editAmount"
                    type="number"
                    value={editFormData.amount}
                    onChange={(e) => setEditFormData({...editFormData, amount: e.target.value})}
                    placeholder="Masukkan jumlah"
                    className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="editDate" className="text-blue-700 font-medium">Tanggal</Label>
                  <Input
                    id="editDate"
                    type="date"
                    value={editFormData.date}
                    onChange={(e) => setEditFormData({...editFormData, date: e.target.value})}
                    className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="editDescription" className="text-blue-700 font-medium">Keterangan</Label>
                <Input
                  id="editDescription"
                  value={editFormData.description}
                  onChange={(e) => setEditFormData({...editFormData, description: e.target.value})}
                  placeholder="Masukkan keterangan transaksi"
                  className="border-blue-200 focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Batal
              </Button>
              <Button onClick={handleUpdate} className="bg-blue-600 hover:bg-blue-700">
                Simpan Perubahan
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent className="bg-white border-red-200">
            <DialogHeader>
              <DialogTitle className="text-red-600">Konfirmasi Hapus</DialogTitle>
              <DialogDescription>
                Apakah Anda yakin ingin menghapus transaksi ini? Tindakan ini tidak dapat dibatalkan.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Batal
              </Button>
              <Button variant="destructive" onClick={confirmDelete}>
                Ya, Hapus
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Reset Confirmation Dialog */}
        <Dialog open={isResetDialogOpen} onOpenChange={setIsResetDialogOpen}>
          <DialogContent className="bg-white border-red-200">
            <DialogHeader>
              <DialogTitle className="text-red-600">Konfirmasi Reset</DialogTitle>
              <DialogDescription>
                Apakah Anda yakin ingin mereset semua transaksi? Tindakan ini tidak dapat dibatalkan dan semua data akan hilang permanen.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsResetDialogOpen(false)}>
                Batal
              </Button>
              <Button variant="destructive" onClick={handleReset}>
                Ya, Reset Semua
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Logout Confirmation Dialog */}
        <Dialog open={isLogoutDialogOpen} onOpenChange={setIsLogoutDialogOpen}>
          <DialogContent className="bg-white border-orange-200">
            <DialogHeader>
              <DialogTitle className="text-orange-600">Konfirmasi Logout</DialogTitle>
              <DialogDescription>
                Semua transaksi akan otomatis tersimpan di database. Apakah Anda ingin melanjutkan?
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsLogoutDialogOpen(false)}>
                Batal
              </Button>
              <Button variant="default" onClick={handleLogout} className="bg-orange-600 hover:bg-orange-700">
                Ya, Logout
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}