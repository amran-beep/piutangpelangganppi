import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    // Get all customers with their transactions
    const customers = await db.customer.findMany({
      include: {
        transactions: {
          orderBy: {
            date: 'desc'
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    })

    // Calculate summaries
    const customerSummaries = customers.map(customer => {
      const totalDebt = customer.transactions
        .filter(t => t.type === 'debt')
        .reduce((sum, t) => sum + t.amount, 0)
      
      const totalPayment = customer.transactions
        .filter(t => t.type === 'payment')
        .reduce((sum, t) => sum + t.amount, 0)
      
      const remainingDebt = totalDebt - totalPayment
      const transactionCount = customer.transactions.length

      return {
        customerName: customer.name,
        totalDebt,
        totalPayment,
        remainingDebt,
        transactionCount
      }
    })

    // Get all transactions for detail
    const allTransactions = await db.transaction.findMany({
      include: {
        customer: {
          select: {
            name: true
          }
        }
      },
      orderBy: {
        date: 'desc'
      }
    })

    // Generate report content
    let report = 'LAPORAN PIUTANG PELANGGAN PPI\n'
    report += 'PT RURA SEJAHTERA GRUP\n'
    report += '=' .repeat(50) + '\n'
    report += `Tanggal Cetak: ${new Date().toLocaleDateString('id-ID')}\n`
    report += `Waktu Cetak: ${new Date().toLocaleTimeString('id-ID')}\n\n`
    
    // Summary statistics
    const totalDebt = customerSummaries.reduce((sum, customer) => sum + customer.totalDebt, 0)
    const totalPayment = customerSummaries.reduce((sum, customer) => sum + customer.totalPayment, 0)
    const totalRemaining = totalDebt - totalPayment
    
    report += 'RINGKASAN KESELURUHAN\n'
    report += '-'.repeat(30) + '\n'
    report += `Total Pelanggan: ${customerSummaries.length}\n`
    report += `Total Hutang Seluruhnya: Rp ${totalDebt.toLocaleString('id-ID')}\n`
    report += `Total Pembayaran Seluruhnya: Rp ${totalPayment.toLocaleString('id-ID')}\n`
    report += `Sisa Hutang Seluruhnya: Rp ${totalRemaining.toLocaleString('id-ID')}\n\n`
    
    // Customer summaries
    report += 'RINGKASAN PER PELANGGAN\n'
    report += '-'.repeat(30) + '\n'
    customerSummaries.forEach(summary => {
      report += `Pelanggan: ${summary.customerName}\n`
      report += `Total Hutang: Rp ${summary.totalDebt.toLocaleString('id-ID')}\n`
      report += `Total Pembayaran: Rp ${summary.totalPayment.toLocaleString('id-ID')}\n`
      report += `Sisa Hutang: Rp ${summary.remainingDebt.toLocaleString('id-ID')}\n`
      report += `Jumlah Transaksi: ${summary.transactionCount}\n`
      report += '-'.repeat(30) + '\n'
    })
    
    report += '\nDETIL TRANSAKSI\n'
    report += '-'.repeat(30) + '\n'
    
    allTransactions.forEach((transaction, index) => {
      report += `\nTransaksi #${index + 1}\n`
      report += `Tanggal: ${transaction.date}\n`
      report += `Pelanggan: ${transaction.customer.name}\n`
      report += `Divisi: ${transaction.division}\n`
      report += `Jenis: ${transaction.type === 'debt' ? 'Hutang' : 'Pembayaran'}\n`
      report += `Jumlah: Rp ${transaction.amount.toLocaleString('id-ID')}\n`
      report += `Keterangan: ${transaction.description}\n`
      report += `Dibuat pada: ${new Date(transaction.createdAt).toLocaleString('id-ID')}\n`
      report += '-'.repeat(30) + '\n'
    })

    report += '\n' + '=' .repeat(50) + '\n'
    report += 'apps created by @alyafta.id 2025\n'

    // Create response with file download
    const response = new NextResponse(report, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': `attachment; filename="piutang-ppi-report-${new Date().toISOString().split('T')[0]}.txt"`,
      },
    })

    return response
  } catch (error) {
    console.error('Error generating backup:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to generate backup' },
      { status: 500 }
    )
  }
}