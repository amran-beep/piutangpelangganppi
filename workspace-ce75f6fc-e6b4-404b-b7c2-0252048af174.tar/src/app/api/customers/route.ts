import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get('search')
    const division = searchParams.get('division')

    let customers = await db.customer.findMany({
      include: {
        transactions: {
          orderBy: {
            date: 'desc'
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    })

    // Apply filters
    if (search) {
      customers = customers.filter(customer => 
        customer.name.toLowerCase().includes(search.toLowerCase()) ||
        customer.email?.toLowerCase().includes(search.toLowerCase()) ||
        customer.phone?.includes(search)
      )
    }

    if (division && division !== 'all') {
      customers = customers.filter(customer => customer.division === division)
    }

    // Calculate summary for each customer
    const customersWithSummary = customers.map(customer => {
      const totalDebt = customer.transactions
        .filter(t => t.type === 'debt')
        .reduce((sum, t) => sum + t.amount, 0)
      
      const totalPayment = customer.transactions
        .filter(t => t.type === 'payment')
        .reduce((sum, t) => sum + t.amount, 0)
      
      const remainingDebt = totalDebt - totalPayment
      const transactionCount = customer.transactions.length

      return {
        ...customer,
        totalDebt,
        totalPayment,
        remainingDebt,
        transactionCount
      }
    })

    return NextResponse.json({
      success: true,
      data: customersWithSummary,
      total: customersWithSummary.length
    })
  } catch (error) {
    console.error('Error fetching customers:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch customers' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, phone, address, email, division } = body

    if (!name || !division) {
      return NextResponse.json(
        { success: false, error: 'Name and division are required' },
        { status: 400 }
      )
    }

    // Check if customer already exists
    const existingCustomer = await db.customer.findUnique({
      where: { name }
    })

    if (existingCustomer) {
      return NextResponse.json(
        { success: false, error: 'Customer with this name already exists' },
        { status: 400 }
      )
    }

    const customer = await db.customer.create({
      data: {
        name,
        phone,
        address,
        email,
        division
      }
    })

    return NextResponse.json({
      success: true,
      data: customer,
      message: 'Customer created successfully'
    })
  } catch (error) {
    console.error('Error creating customer:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create customer' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, name, phone, address, email, division } = body

    if (!id || !name || !division) {
      return NextResponse.json(
        { success: false, error: 'ID, name, and division are required' },
        { status: 400 }
      )
    }

    // Check if customer exists
    const existingCustomer = await db.customer.findUnique({
      where: { id }
    })

    if (!existingCustomer) {
      return NextResponse.json(
        { success: false, error: 'Customer not found' },
        { status: 404 }
      )
    }

    // Check if name conflicts with another customer
    const nameConflict = await db.customer.findFirst({
      where: {
        name,
        id: { not: id }
      }
    })

    if (nameConflict) {
      return NextResponse.json(
        { success: false, error: 'Customer with this name already exists' },
        { status: 400 }
      )
    }

    const customer = await db.customer.update({
      where: { id },
      data: {
        name,
        phone,
        address,
        email,
        division
      }
    })

    return NextResponse.json({
      success: true,
      data: customer,
      message: 'Customer updated successfully'
    })
  } catch (error) {
    console.error('Error updating customer:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update customer' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Customer ID is required' },
        { status: 400 }
      )
    }

    // Check if customer exists
    const existingCustomer = await db.customer.findUnique({
      where: { id },
      include: {
        transactions: true
      }
    })

    if (!existingCustomer) {
      return NextResponse.json(
        { success: false, error: 'Customer not found' },
        { status: 404 }
      )
    }

    // Check if customer has transactions
    if (existingCustomer.transactions.length > 0) {
      return NextResponse.json(
        { success: false, error: 'Cannot delete customer with existing transactions' },
        { status: 400 }
      )
    }

    await db.customer.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Customer deleted successfully'
    })
  } catch (error) {
    console.error('Error deleting customer:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete customer' },
      { status: 500 }
    )
  }
}