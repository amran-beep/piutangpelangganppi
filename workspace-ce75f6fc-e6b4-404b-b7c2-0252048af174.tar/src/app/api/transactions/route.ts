import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const customerId = searchParams.get('customerId')
    const customerName = searchParams.get('customerName')
    const type = searchParams.get('type')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    let whereClause: any = {}

    if (customerId) {
      whereClause.customerId = customerId
    }

    if (customerName) {
      whereClause.customer = {
        name: {
          contains: customerName,
          mode: 'insensitive'
        }
      }
    }

    if (type && type !== 'all') {
      whereClause.type = type
    }

    if (startDate && endDate) {
      whereClause.date = {
        gte: startDate,
        lte: endDate
      }
    } else if (startDate) {
      whereClause.date = {
        gte: startDate
      }
    } else if (endDate) {
      whereClause.date = {
        lte: endDate
      }
    }

    const transactions = await db.transaction.findMany({
      where: whereClause,
      include: {
        customer: {
          select: {
            id: true,
            name: true,
            division: true
          }
        }
      },
      orderBy: {
        date: 'desc'
      }
    })

    return NextResponse.json({
      success: true,
      data: transactions,
      total: transactions.length
    })
  } catch (error) {
    console.error('Error fetching transactions:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch transactions' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { customerId, customerName, division, type, amount, description, date } = body

    if (!customerName || !division || !type || !amount || !description || !date) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    let finalCustomerId = customerId

    // If customerId not provided, create or find customer
    if (!finalCustomerId) {
      let customer = await db.customer.findUnique({
        where: { name: customerName }
      })

      if (!customer) {
        customer = await db.customer.create({
          data: {
            name: customerName,
            division
          }
        })
      }

      finalCustomerId = customer.id
    }

    const transaction = await db.transaction.create({
      data: {
        customerId: finalCustomerId,
        type,
        amount: parseFloat(amount),
        description,
        date,
        division
      },
      include: {
        customer: {
          select: {
            id: true,
            name: true,
            division: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: transaction,
      message: 'Transaction created successfully'
    })
  } catch (error) {
    console.error('Error creating transaction:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create transaction' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, customerId, customerName, division, type, amount, description, date } = body

    if (!id || !customerName || !division || !type || !amount || !description || !date) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    let finalCustomerId = customerId

    // If customerId not provided, create or find customer
    if (!finalCustomerId) {
      let customer = await db.customer.findUnique({
        where: { name: customerName }
      })

      if (!customer) {
        customer = await db.customer.create({
          data: {
            name: customerName,
            division
          }
        })
      }

      finalCustomerId = customer.id
    }

    const transaction = await db.transaction.update({
      where: { id },
      data: {
        customerId: finalCustomerId,
        type,
        amount: parseFloat(amount),
        description,
        date,
        division
      },
      include: {
        customer: {
          select: {
            id: true,
            name: true,
            division: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: transaction,
      message: 'Transaction updated successfully'
    })
  } catch (error) {
    console.error('Error updating transaction:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update transaction' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (id) {
      // Delete specific transaction
      const transaction = await db.transaction.findUnique({
        where: { id }
      })

      if (!transaction) {
        return NextResponse.json(
          { success: false, error: 'Transaction not found' },
          { status: 404 }
        )
      }

      await db.transaction.delete({
        where: { id }
      })

      return NextResponse.json({
        success: true,
        message: 'Transaction deleted successfully'
      })
    } else {
      // Reset all transactions
      await db.transaction.deleteMany({})

      return NextResponse.json({
        success: true,
        message: 'All transactions reset successfully'
      })
    }
  } catch (error) {
    console.error('Error deleting transactions:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete transactions' },
      { status: 500 }
    )
  }
}